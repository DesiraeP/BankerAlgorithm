#include "bank.h"
#include <string>
#include <iostream>
#include <thread>
#include <mutex>

class BankImpl : public Bank {
private:
	int numOfThreads;
	int numOfResources;

	std::vector<int> available;
	std::vector<std::vector<int>> maximum;
	std::vector<std::vector<int>> allocation;
	std::vector<std::vector<int>> need;
	std::vector<bool> finished;
	std::mutex lock;

	void showAllMatrices(const std::vector<std::vector<int>>& alloc,
		const std::vector<std::vector<int>>& max,
		const std::vector<std::vector<int>>& need, const std::string& msg) {
		std::cout << msg;
		std::cout << "Allocated   Max        Need";
		for (int i = 0; i < numOfThreads; i++) {
			std::cout << "\n";
			std::vector<int> a = alloc[i];
			showVector(a, " ", finished[i]);
			std::cout << "  ";
			std::vector<int> m = max[i];
			showVector(m, " ", finished[i]);
			std::cout << "  ";
			std::vector<int> n= need[i];
			showVector(n, " ", finished[i]);
			std::cout << "  ";
		}
		std::cout << "\n";
	};
	void showVector(std::vector<int>& vect, std::string msg, bool finished = false)
	{
		if (finished) {
			std::cout << "//////";
			return;
		}
		std::cout << msg << "[" << vect[0];
		int vectlen = vect.size();
		for (int i = 1; i < vectlen; i++) {
			std::cout << " " << vect[i];
		}
		std::cout << "]";

	}
	bool isAvailable(const std::vector<int>& resource)
	{
		int reslen = resource.size();
		for (int i = 0; i < reslen; i++) {
			if (available[i] < resource[i]) {
				return false;
			}
		}
		return true;
	}

	void allocate(int threadNum, std::vector<int>& resource) {
		int reslen = resource.size();
		for (int i = 0; i < reslen; i++) {
			available[i] = available[i] - resource[i];
			allocation[threadNum][i] = allocation[threadNum][i] + resource[i];
			need[threadNum][i] = need[threadNum][i] - resource[i];
		}
	}

	void deallocate(int threadNum, std::vector<int>& resource) {
		int reslen = resource.size();
		for (int i = 0; i < reslen; i++) {
			available[i] = available[i] + resource[i];
			allocation[threadNum][i] = allocation[threadNum][i] - resource[i];
			need[threadNum][i] = need[threadNum][i] + resource[i];
		}
	}
	bool hasMaximum(int threadNum) {
		int allsize = allocation[threadNum].size();
		for (int i = 0; i < allsize; i++) {
			if (allocation[threadNum][i] < maximum[threadNum][i]) {
				return false;
			}
		}
		return true;
	}
	bool isProcessFinished() {
		for (int i = 0; i < numOfThreads; i++) {
			if (!finished[i]) {
				return false;
			}
		}
		return true;
	}
	std::vector<int> cpath;

	bool isSafeState(int threadNum, std::vector<int>& request) {
		if (!isAvailable(request)) {
			return false;
		}

		std::vector<int> orAll = allocation[threadNum];
		bool isSafe = false;

		allocate(threadNum, request);
		// reached Max
		if (hasMaximum(threadNum)) {
			deallocate(threadNum, allocation[threadNum]);
			finished[threadNum] = true;
		}

		// finished threads
		if (isProcessFinished()) {
			isSafe = true;
		}
		else {
			for (int i = 0; i < numOfThreads; i++) {
				if (!finished[i]) {
					isSafe = isSafeState(i, need[i]);
					if (isSafe) {
						break;
					}
				}
			}
		}

		if (finished[threadNum]) {
			allocate(threadNum, orAll);
		}
		else {
			deallocate(threadNum, request);
		}
		finished[threadNum] = false;
		return isSafe;
	}

public:
	BankImpl(std::vector<int>& resources) {
		available = resources;
		numOfThreads = 0;
	}
	void changeResources(std::vector<int>& resources) {
		available = resources;
	}
	void addCustomer(int threadNum, std::vector<int>& maxDemand, std::vector<int>& allocated)
	{
		allocation.push_back(allocated);
		maximum.push_back(maxDemand);
		std::vector<int> n;
		int allsize = allocated.size();
		for (int i = 0; i < allsize; i++) {
			n.push_back(maxDemand[i] - allocated[i]);
		}
		need.push_back(n);
		finished.push_back(false);
		numOfThreads++;
	}
	void getState() {
		std::cout << "\n";
		showVector(available, "Available");
		std::cout << "\n";
		showAllMatrices(allocation, maximum, need, "");
		std::cout << "\n";
	}
	int requestResources(int threadNum, std::vector<int>& request) {
		std::lock_guard<std::mutex>lock(lock);
		int rq = request.size();
		for (int i = 0; i < rq; i++) {
			if ((request[i] > need[threadNum][i]) || (request[i] > available[i])) {
				return -1;
			}
		}
		std::cout << "#P" << threadNum << " ";
		showVector(request, "rq:");
		showVector(need[threadNum], ", needs:");
		showVector(available, ", available=");
		if (isSafeState(threadNum, request)) {
			allocate(threadNum, request);
			std::cout << "Approved, #P" << threadNum;
			std::cout << "\n";
			getState();
			return 1;
		}
		else {
			std::cout << " Denied\n";
			return 0;
		}

	}
	int getResources() { return numOfResources; }
	bool releaseResources(int threadNum) {
		std::lock_guard<std::mutex>lock(lock);
		// did it reach max
		if (!hasMaximum(threadNum)) {
			return false;
		}
		std::cout << ">#P " << threadNum << "has all of its resources (releasing and shutting down) \n\n";
		std::cout << "customer # " << threadNum;
		showVector(allocation[threadNum], "releasing:");
		deallocate(threadNum, allocation[threadNum]);
		finished[threadNum] = true;
		return true;

	}
	bool needMet(int threadnum) {
		return hasMaximum(threadnum);
	}
};
