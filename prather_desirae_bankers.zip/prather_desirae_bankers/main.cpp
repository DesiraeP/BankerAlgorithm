#include <iostream>
#include <fstream>
#include <vector>
#include <thread>
#include <string>
#include <sstream>
#include <cstdlib>
#include "customer.h"
void emptyvector(std::vector<int>&vec) {
	while (!vec.empty()) {
		vec.pop_back();
	}
}
std::vector<int> createRequest() {
	int max = 7;
	std::vector<int> request;
	for (int i = 0; i < 3; i++) {
		request.push_back(rand() % max);
	}
	return request;
}
/*
void* runner(void *p){ // created runner function but did not work
Customer* custom =(Customer*)p;

BankImpl* bank = custom->getBank();

while (!bank->needMet(custom->getid())) {
	std::vector<int> request = createRequest();
	bank->requestResources(custom->getid(),request); // will also approve or deny request
	if (bank->needMet(custom->getid())) {
		bank->releaseResources(custom->getid());// releases all of the resources once it reaches max
	}
}
}*/

int main(int argc, const char* argv[]) {           // TODO   fill in missing code
  // read available resources from command line
	std::vector<int> resources;

	std::vector<Customer> customers;
	std::vector<std::thread>   workers;
	BankImpl              theBank(resources);
	std::vector<int>      maxDemand;
	std::vector<int>      allocated;

	int threadNum = 0;

	// open input file, and read in resources, bank, and customer data from file
	std::fstream newfile;
  std::string filename ="infileSmall.txt";//change filename here
	newfile.open(filename);
	std::string line;
	int num;
	int size = 1;
	if (newfile.is_open()) {
		//gets resources/avaiable
		std::getline(newfile, line);
		std::stringstream iss(line);
		while (iss >> num) {
			resources.push_back(num);
		}
		theBank.changeResources(resources);
		// get the rest of the data for each process
		while (std::getline(newfile, line)) {
			std::stringstream iss(line);
			while (iss >> num) {
				if ((size == 1) || (size == 2) || (size == 3)) {// gets the allocated data
					allocated.push_back(num);
					size++;
				}
				else if ((size == 4) || (size == 5) || (size == 6)) { // gets the maxDemand
					maxDemand.push_back(num);
					size++;
				}
			}
			size = 1;
			theBank.addCustomer(threadNum, maxDemand, allocated);
			Customer customer(threadNum, maxDemand, theBank);
			customers.push_back(customer);
			threadNum++;
			emptyvector(allocated);// clears prevous process allocated data to get the next processs allocated data
			emptyvector(maxDemand);// clears prevous process max data to get the next processs max data
		}
		newfile.close();
	}
	else
	{
		std::cerr << "\n\nWarning, could not open file. \n";
	}
	// print state of bank and start threads
	theBank.getState();
	srand(time(0));
	
	/*//create threads (but it did not work)
	//Bankers algorithm simulation start
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_mutexattr_init(&mutex_attr);
	pthread_mutex_init(&mutex_,&mutex_attr);

	auto it = customers.begin();// an iterator to go through the  customer object vector
	for(; it != customers.end(); it++){
	pthread_create((*it).getid(),&attr, runner, (*it));
	}

	//join threads
	auto it = customers.begin();
	for(; it != customers.end(); it++){
	pthread_join((*it).getid(),NULL);
	}
	
	
	*/


	// wait for all threads to complete - this was from the skeleton code
//	for (int i = 0; i < workers.size(); i++) {
		//workers[i].join();
//	}
}

